import { useState } from 'react';
import { AuthProvider, useAuth } from '@/context/AuthContext';
import { supabase, type Destination } from '@/lib/supabase';
import LoginPage from '@/pages/LoginPage';
import Navbar from '@/components/Navbar';
import HomePage from '@/pages/HomePage';
import ExplorePage from '@/pages/ExplorePage';
import SavedTripsPage from '@/pages/SavedTripsPage';
import ProfilePage from '@/pages/ProfilePage';
import DestinationDetailPage from '@/pages/DestinationDetailPage';
import { Loader2 } from 'lucide-react';

type Page = 'home' | 'explore' | 'saved' | 'profile' | 'detail';

function AppContent() {
  const { session, loading } = useAuth();
  const [page, setPage] = useState<Page>('home');
  const [selectedDestination, setSelectedDestination] = useState<Destination | null>(null);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-50">
        <div className="flex flex-col items-center gap-4">
          <Loader2 className="w-10 h-10 animate-spin text-cyan-600" />
          <p className="text-slate-400 text-sm">Loading TravelMate...</p>
        </div>
      </div>
    );
  }

  if (!session) {
    return <LoginPage />;
  }

  const handleNavigate = (newPage: Page) => {
    setPage(newPage);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const openDestination = (dest: Destination) => {
    setSelectedDestination(dest);
    setPage('detail');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleSignOut = async () => {
    await supabase.auth.signOut();
    setPage('home');
  };

  return (
    <>
      <Navbar currentPage={page} onNavigate={handleNavigate} />
      {page === 'home' && <HomePage onNavigate={handleNavigate} onOpenDestination={openDestination} />}
      {page === 'explore' && <ExplorePage onOpenDestination={openDestination} />}
      {page === 'saved' && <SavedTripsPage onOpenDestination={openDestination} onNavigate={handleNavigate} />}
      {page === 'profile' && <ProfilePage onOpenDestination={openDestination} onSignOut={handleSignOut} />}
      {page === 'detail' && selectedDestination && (
        <DestinationDetailPage
          destination={selectedDestination}
          onBack={() => handleNavigate('explore')}
        />
      )}
    </>
  );
}

function App() {
  return (
    <AuthProvider>
      <AppContent />
    </AuthProvider>
  );
}

export default App;
