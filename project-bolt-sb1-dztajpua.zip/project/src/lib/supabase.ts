import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

export const supabase = createClient(supabaseUrl, supabaseAnonKey, {
  auth: {
    persistSession: true,
    autoRefreshToken: true,
  },
});

export type Destination = {
  id: string;
  name: string;
  country: string;
  description: string;
  image_url: string;
  gallery: string[];
  category: string;
  price: number;
  rating: number;
  reviews_count: number;
  duration_days: number;
  best_season: string;
  created_at: string;
};

export type SavedTrip = {
  id: string;
  user_id: string;
  destination_id: string;
  planned_date: string | null;
  status: string;
  notes: string;
  created_at: string;
  destination?: Destination;
};

export type UserProfile = {
  id: string;
  full_name: string;
  avatar_url: string;
  bio: string;
  created_at: string;
};
