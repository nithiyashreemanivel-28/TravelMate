import { useAuth } from '@/context/AuthContext';
import { Plane, Home, Compass, Heart, User as UserIcon, LogOut } from 'lucide-react';

type Page = 'home' | 'explore' | 'saved' | 'profile' | 'detail';

type Props = {
  currentPage: Page;
  onNavigate: (page: Page) => void;
};

export default function Navbar({ currentPage, onNavigate }: Props) {
  const { user, signOut } = useAuth();

  const navItems: { key: Page; label: string; icon: typeof Home }[] = [
    { key: 'home', label: 'Home', icon: Home },
    { key: 'explore', label: 'Explore', icon: Compass },
    { key: 'saved', label: 'Saved', icon: Heart },
    { key: 'profile', label: 'Profile', icon: UserIcon },
  ];

  return (
    <>
      {/* Desktop navbar */}
      <nav className="hidden md:flex fixed top-0 left-0 right-0 z-50 bg-white/80 backdrop-blur-lg border-b border-slate-100">
        <div className="max-w-7xl mx-auto w-full px-6 h-16 flex items-center justify-between">
          <button onClick={() => onNavigate('home')} className="flex items-center gap-2.5 group">
            <div className="w-9 h-9 rounded-xl bg-cyan-600 flex items-center justify-center group-hover:bg-cyan-700 transition-colors">
              <Plane className="w-5 h-5 text-white" />
            </div>
            <span className="text-xl font-bold text-slate-800" style={{ fontFamily: 'Poppins, sans-serif' }}>
              TravelMate
            </span>
          </button>

          <div className="flex items-center gap-1">
            {navItems.map(({ key, label, icon: Icon }) => (
              <button
                key={key}
                onClick={() => onNavigate(key)}
                className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-all ${
                  currentPage === key
                    ? 'bg-cyan-50 text-cyan-700'
                    : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900'
                }`}
              >
                <Icon className="w-4 h-4" />
                {label}
              </button>
            ))}
          </div>

          <div className="flex items-center gap-3">
            <span className="text-sm text-slate-500 hidden lg:block">
              {user?.email}
            </span>
            <button
              onClick={signOut}
              className="flex items-center gap-2 px-3 py-2 rounded-lg text-sm font-medium text-slate-600 hover:bg-red-50 hover:text-red-600 transition-all"
            >
              <LogOut className="w-4 h-4" />
              <span className="hidden sm:inline">Sign out</span>
            </button>
          </div>
        </div>
      </nav>

      {/* Mobile bottom nav */}
      <nav className="md:hidden fixed bottom-0 left-0 right-0 z-50 bg-white border-t border-slate-100 shadow-lg">
        <div className="flex items-center justify-around h-16">
          {navItems.map(({ key, label, icon: Icon }) => (
            <button
              key={key}
              onClick={() => onNavigate(key)}
              className={`flex flex-col items-center gap-0.5 px-3 py-1.5 transition-colors ${
                currentPage === key ? 'text-cyan-600' : 'text-slate-400'
              }`}
            >
              <Icon className={`w-5 h-5 ${currentPage === key ? 'fill-cyan-50' : ''}`} />
              <span className="text-[10px] font-medium">{label}</span>
            </button>
          ))}
        </div>
      </nav>
    </>
  );
}
