import { Star, MapPin, Clock, Heart } from 'lucide-react';
import type { Destination } from '@/lib/supabase';

type Props = {
  destination: Destination;
  onClick: () => void;
  isSaved: boolean;
  onToggleSave: () => void;
  index?: number;
};

export default function DestinationCard({ destination, onClick, isSaved, onToggleSave, index = 0 }: Props) {
  return (
    <div
      onClick={onClick}
      className="group cursor-pointer bg-white rounded-2xl overflow-hidden card-shadow hover:card-shadow-hover transition-all duration-300 hover:-translate-y-1 animate-slide-up"
      style={{ animationDelay: `${index * 80}ms`, opacity: 0 }}
    >
      <div className="relative h-56 overflow-hidden">
        <img
          src={destination.image_url}
          alt={destination.name}
          className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
          loading="lazy"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/40 to-transparent" />
        <div className="absolute top-3 left-3 px-3 py-1.5 rounded-full bg-white/90 backdrop-blur-sm text-xs font-semibold text-slate-700 capitalize">
          {destination.category}
        </div>
        <button
          onClick={(e) => {
            e.stopPropagation();
            onToggleSave();
          }}
          className="absolute top-3 right-3 w-9 h-9 rounded-full bg-white/90 backdrop-blur-sm flex items-center justify-center hover:scale-110 transition-transform"
        >
          <Heart
            className={`w-5 h-5 transition-colors ${
              isSaved ? 'fill-red-500 text-red-500' : 'text-slate-600'
            }`}
          />
        </button>
        <div className="absolute bottom-3 left-3 flex items-center gap-1.5 text-white">
          <MapPin className="w-4 h-4" />
          <span className="text-sm font-medium">{destination.country}</span>
        </div>
      </div>

      <div className="p-5">
        <div className="flex items-start justify-between mb-2">
          <h3 className="text-lg font-bold text-slate-800" style={{ fontFamily: 'Poppins, sans-serif' }}>
            {destination.name}
          </h3>
          <div className="flex items-center gap-1">
            <Star className="w-4 h-4 text-amber-500 fill-amber-500" />
            <span className="text-sm font-semibold text-slate-700">{destination.rating}</span>
            <span className="text-xs text-slate-400">({destination.reviews_count.toLocaleString()})</span>
          </div>
        </div>

        <p className="text-sm text-slate-500 leading-relaxed line-clamp-2 mb-4">
          {destination.description}
        </p>

        <div className="flex items-center justify-between pt-3 border-t border-slate-100">
          <div className="flex items-center gap-1.5 text-slate-500">
            <Clock className="w-4 h-4" />
            <span className="text-sm">{destination.duration_days} days</span>
          </div>
          <div>
            <span className="text-xs text-slate-400">from </span>
            <span className="text-lg font-bold text-cyan-700">${destination.price.toLocaleString()}</span>
          </div>
        </div>
      </div>
    </div>
  );
}
