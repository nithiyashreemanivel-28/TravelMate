import { useEffect, useState } from 'react';
import { supabase, type Destination, type SavedTrip } from '@/lib/supabase';
import { useAuth } from '@/context/AuthContext';
import DestinationCard from '@/components/DestinationCard';
import { Search, MapPin, Compass, TrendingUp, Calendar, Plane, ArrowRight, Star } from 'lucide-react';

type Props = {
  onNavigate: (page: 'home' | 'explore' | 'saved' | 'profile' | 'detail') => void;
  onOpenDestination: (destination: Destination) => void;
};

export default function HomePage({ onNavigate, onOpenDestination }: Props) {
  const { user } = useAuth();
  const [destinations, setDestinations] = useState<Destination[]>([]);
  const [savedIds, setSavedIds] = useState<Set<string>>(new Set());
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');

  useEffect(() => {
    loadDestinations();
  }, []);

  useEffect(() => {
    if (user) loadSaved();
  }, [user]);

  const loadDestinations = async () => {
    const { data } = await supabase
      .from('destinations')
      .select('*')
      .order('rating', { ascending: false })
      .limit(6);
    if (data) setDestinations(data as Destination[]);
    setLoading(false);
  };

  const loadSaved = async () => {
    const { data } = await supabase
      .from('saved_trips')
      .select('destination_id');
    if (data) {
      setSavedIds(new Set((data as SavedTrip[]).map((t) => t.destination_id)));
    }
  };

  const toggleSave = async (destinationId: string) => {
    if (!user) return;
    if (savedIds.has(destinationId)) {
      await supabase.from('saved_trips').delete().eq('destination_id', destinationId);
      setSavedIds((prev) => {
        const next = new Set(prev);
        next.delete(destinationId);
        return next;
      });
    } else {
      await supabase.from('saved_trips').insert({ destination_id: destinationId });
      setSavedIds((prev) => new Set(prev).add(destinationId));
    }
  };

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    onNavigate('explore');
  };

  const featured = destinations[0];
  const popular = destinations.slice(1, 5);

  return (
    <div className="min-h-screen pt-16 md:pt-16 pb-20 md:pb-8 bg-slate-50">
      {/* Hero Section */}
      <section className="relative h-[600px] overflow-hidden mb-16">
        {featured && (
          <img
            src={featured.image_url}
            alt={featured.name}
            className="absolute inset-0 w-full h-full object-cover"
          />
        )}
        <div className="absolute inset-0 hero-gradient" />

        <div className="relative z-10 h-full flex flex-col items-center justify-center text-center px-6 max-w-4xl mx-auto">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-white/15 backdrop-blur-sm border border-white/20 text-white text-sm font-medium mb-6 animate-fade-in">
            <Compass className="w-4 h-4" />
            Discover your next adventure
          </div>

          <h1 className="text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-extrabold text-white leading-tight mb-6 text-shadow-lg animate-slide-up" style={{ fontFamily: 'Poppins, sans-serif' }}>
            Travel makes you<br />speechless, then a<br />storyteller
          </h1>

          <p className="text-lg text-white/90 mb-8 max-w-2xl leading-relaxed animate-slide-up" style={{ animationDelay: '100ms', opacity: 0 }}>
            Explore curated destinations, compare experiences, and plan the trip of your dreams with TravelMate.
          </p>

          {/* Search bar */}
          <form onSubmit={handleSearch} className="w-full max-w-2xl bg-white rounded-2xl p-2 flex items-center gap-2 shadow-2xl animate-slide-up" style={{ animationDelay: '200ms', opacity: 0 }}>
            <div className="flex-1 flex items-center gap-2 px-3">
              <Search className="w-5 h-5 text-slate-400 shrink-0" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Where do you want to go?"
                className="w-full py-3 text-slate-800 placeholder-slate-400 focus:outline-none bg-transparent"
              />
            </div>
            <button
              type="submit"
              className="px-6 py-3 rounded-xl bg-cyan-600 hover:bg-cyan-700 text-white font-semibold transition-all flex items-center gap-2 whitespace-nowrap"
            >
              Search
              <ArrowRight className="w-4 h-4" />
            </button>
          </form>

          {/* Quick stats */}
          <div className="flex items-center gap-8 mt-10 text-white animate-fade-in" style={{ animationDelay: '400ms' }}>
            <div className="text-center">
              <div className="text-3xl font-bold">120+</div>
              <div className="text-sm text-white/70">Destinations</div>
            </div>
            <div className="w-px h-12 bg-white/20" />
            <div className="text-center">
              <div className="text-3xl font-bold">50+</div>
              <div className="text-sm text-white/70">Countries</div>
            </div>
            <div className="w-px h-12 bg-white/20" />
            <div className="text-center">
              <div className="text-3xl font-bold flex items-center gap-1">
                4.9
                <Star className="w-5 h-5 fill-amber-300 text-amber-300" />
              </div>
              <div className="text-sm text-white/70">Avg Rating</div>
            </div>
          </div>
        </div>
      </section>

      {/* Categories */}
      <section className="max-w-7xl mx-auto px-6 mb-16">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {[
            { label: 'Beaches', icon: '🏖️', color: 'from-cyan-500 to-blue-500' },
            { label: 'Cities', icon: '🏙️', color: 'from-slate-600 to-slate-800' },
            { label: 'Mountains', icon: '🏔️', color: 'from-teal-500 to-emerald-600' },
            { label: 'Cultural', icon: '🏛️', color: 'from-amber-500 to-orange-600' },
          ].map((cat, i) => (
            <button
              key={cat.label}
              onClick={() => onNavigate('explore')}
              className={`group relative h-32 rounded-2xl bg-gradient-to-br ${cat.color} p-5 flex flex-col justify-between text-left overflow-hidden hover:scale-105 transition-transform animate-scale-in`}
              style={{ animationDelay: `${i * 80}ms`, opacity: 0 }}
            >
              <div className="text-3xl">{cat.icon}</div>
              <div className="text-white">
                <div className="text-lg font-bold">{cat.label}</div>
                <div className="text-sm text-white/70 flex items-center gap-1">
                  Explore <ArrowRight className="w-3 h-3 group-hover:translate-x-1 transition-transform" />
                </div>
              </div>
            </button>
          ))}
        </div>
      </section>

      {/* Popular Destinations */}
      <section className="max-w-7xl mx-auto px-6 mb-16">
        <div className="flex items-center justify-between mb-8">
          <div>
            <div className="flex items-center gap-2 text-cyan-600 mb-2">
              <TrendingUp className="w-5 h-5" />
              <span className="text-sm font-semibold uppercase tracking-wide">Trending Now</span>
            </div>
            <h2 className="text-3xl font-bold text-slate-800" style={{ fontFamily: 'Poppins, sans-serif' }}>
              Popular Destinations
            </h2>
          </div>
          <button
            onClick={() => onNavigate('explore')}
            className="flex items-center gap-1.5 text-sm font-semibold text-cyan-600 hover:text-cyan-700 transition-colors"
          >
            View all
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>

        {loading ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {[...Array(6)].map((_, i) => (
              <div key={i} className="bg-white rounded-2xl overflow-hidden card-shadow animate-pulse">
                <div className="h-56 bg-slate-200" />
                <div className="p-5 space-y-3">
                  <div className="h-5 bg-slate-200 rounded w-2/3" />
                  <div className="h-4 bg-slate-200 rounded w-full" />
                  <div className="h-4 bg-slate-200 rounded w-1/2" />
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {destinations.map((dest, i) => (
              <DestinationCard
                key={dest.id}
                destination={dest}
                index={i}
                onClick={() => onOpenDestination(dest)}
                isSaved={savedIds.has(dest.id)}
                onToggleSave={() => toggleSave(dest.id)}
              />
            ))}
          </div>
        )}
      </section>

      {/* Why Choose Us */}
      <section className="max-w-7xl mx-auto px-6 mb-16">
        <div className="bg-white rounded-3xl p-8 md:p-12 card-shadow">
          <div className="text-center mb-10">
            <h2 className="text-3xl font-bold text-slate-800 mb-3" style={{ fontFamily: 'Poppins, sans-serif' }}>
              Why Travel With Us
            </h2>
            <p className="text-slate-500 max-w-xl mx-auto">
              We make travel planning effortless, so you can focus on the experience.
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              { icon: Compass, title: 'Curated Destinations', desc: 'Hand-picked places verified by travel experts for unforgettable experiences.' },
              { icon: Calendar, title: 'Easy Planning', desc: 'Save trips, set dates, and organize your itinerary all in one place.' },
              { icon: Plane, title: 'Best Prices', desc: 'Transparent pricing with no hidden fees. Get the best value for every trip.' },
            ].map((feat, i) => (
              <div key={feat.title} className="text-center animate-slide-up" style={{ animationDelay: `${i * 100}ms`, opacity: 0 }}>
                <div className="w-14 h-14 rounded-2xl bg-cyan-50 flex items-center justify-center mx-auto mb-4">
                  <feat.icon className="w-7 h-7 text-cyan-600" />
                </div>
                <h3 className="text-lg font-bold text-slate-800 mb-2">{feat.title}</h3>
                <p className="text-sm text-slate-500 leading-relaxed">{feat.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Banner */}
      <section className="max-w-7xl mx-auto px-6">
        <div className="relative rounded-3xl overflow-hidden h-72 flex items-center justify-center text-center">
          <img
            src="https://images.pexels.com/photos/6395044/pexels-photo-6395044.jpeg?auto=compress&cs=tinysrgb&w=1600"
            alt="Adventure awaits"
            className="absolute inset-0 w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-cyan-900/85 to-cyan-700/60" />
          <div className="relative z-10 text-white px-6 max-w-2xl">
            <h2 className="text-3xl md:text-4xl font-extrabold mb-4" style={{ fontFamily: 'Poppins, sans-serif' }}>
              Ready for your next adventure?
            </h2>
            <p className="text-white/85 mb-6">Browse our full catalog of destinations and start planning today.</p>
            <button
              onClick={() => onNavigate('explore')}
              className="px-8 py-3.5 rounded-xl bg-white text-cyan-700 font-semibold hover:bg-cyan-50 transition-all inline-flex items-center gap-2"
            >
              Explore All Destinations
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </section>
    </div>
  );
}
