import { useEffect, useState } from 'react';
import { supabase, type Destination, type SavedTrip } from '@/lib/supabase';
import { useAuth } from '@/context/AuthContext';
import DestinationCard from '@/components/DestinationCard';
import { Search, SlidersHorizontal, X } from 'lucide-react';

type Props = {
  onOpenDestination: (destination: Destination) => void;
};

const categories = ['all', 'beach', 'city', 'mountain', 'cultural', 'adventure'];

export default function ExplorePage({ onOpenDestination }: Props) {
  const { user } = useAuth();
  const [destinations, setDestinations] = useState<Destination[]>([]);
  const [savedIds, setSavedIds] = useState<Set<string>>(new Set());
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [activeCategory, setActiveCategory] = useState('all');
  const [sortBy, setSortBy] = useState<'rating' | 'price-low' | 'price-high'>('rating');

  useEffect(() => {
    loadDestinations();
  }, []);

  useEffect(() => {
    if (user) loadSaved();
  }, [user]);

  const loadDestinations = async () => {
    const { data } = await supabase.from('destinations').select('*');
    if (data) setDestinations(data as Destination[]);
    setLoading(false);
  };

  const loadSaved = async () => {
    const { data } = await supabase.from('saved_trips').select('destination_id');
    if (data) setSavedIds(new Set((data as SavedTrip[]).map((t) => t.destination_id)));
  };

  const toggleSave = async (destinationId: string) => {
    if (!user) return;
    if (savedIds.has(destinationId)) {
      await supabase.from('saved_trips').delete().eq('destination_id', destinationId);
      setSavedIds((prev) => {
        const next = new Set(prev);
        next.delete(destinationId);
        return next;
      });
    } else {
      await supabase.from('saved_trips').insert({ destination_id: destinationId });
      setSavedIds((prev) => new Set(prev).add(destinationId));
    }
  };

  const filtered = destinations
    .filter((d) => {
      const matchesSearch =
        d.name.toLowerCase().includes(search.toLowerCase()) ||
        d.country.toLowerCase().includes(search.toLowerCase());
      const matchesCategory = activeCategory === 'all' || d.category === activeCategory;
      return matchesSearch && matchesCategory;
    })
    .sort((a, b) => {
      if (sortBy === 'price-low') return a.price - b.price;
      if (sortBy === 'price-high') return b.price - a.price;
      return b.rating - a.rating;
    });

  return (
    <div className="min-h-screen pt-20 md:pt-24 pb-20 md:pb-12 bg-slate-50">
      <div className="max-w-7xl mx-auto px-6">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl md:text-4xl font-bold text-slate-800 mb-2" style={{ fontFamily: 'Poppins, sans-serif' }}>
            Explore Destinations
          </h1>
          <p className="text-slate-500">Discover {destinations.length} amazing places around the world</p>
        </div>

        {/* Search + Filters */}
        <div className="flex flex-col sm:flex-row gap-3 mb-6">
          <div className="flex-1 relative">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search by name or country..."
              className="w-full pl-12 pr-4 py-3 rounded-xl border border-slate-200 bg-white text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-cyan-500 focus:border-transparent transition-all"
            />
            {search && (
              <button
                onClick={() => setSearch('')}
                className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
              >
                <X className="w-5 h-5" />
              </button>
            )}
          </div>
          <div className="relative">
            <SlidersHorizontal className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400 pointer-events-none" />
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value as typeof sortBy)}
              className="appearance-none pl-12 pr-10 py-3 rounded-xl border border-slate-200 bg-white text-slate-800 focus:outline-none focus:ring-2 focus:ring-cyan-500 focus:border-transparent transition-all font-medium"
            >
              <option value="rating">Top Rated</option>
              <option value="price-low">Price: Low to High</option>
              <option value="price-high">Price: High to Low</option>
            </select>
          </div>
        </div>

        {/* Category pills */}
        <div className="flex items-center gap-2 mb-8 overflow-x-auto scrollbar-hide pb-2">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setActiveCategory(cat)}
              className={`px-4 py-2 rounded-full text-sm font-medium whitespace-nowrap transition-all capitalize ${
                activeCategory === cat
                  ? 'bg-cyan-600 text-white shadow-lg shadow-cyan-600/20'
                  : 'bg-white text-slate-600 hover:bg-slate-100 border border-slate-200'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Results */}
        {loading ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {[...Array(6)].map((_, i) => (
              <div key={i} className="bg-white rounded-2xl overflow-hidden card-shadow animate-pulse">
                <div className="h-56 bg-slate-200" />
                <div className="p-5 space-y-3">
                  <div className="h-5 bg-slate-200 rounded w-2/3" />
                  <div className="h-4 bg-slate-200 rounded w-full" />
                  <div className="h-4 bg-slate-200 rounded w-1/2" />
                </div>
              </div>
            ))}
          </div>
        ) : filtered.length === 0 ? (
          <div className="text-center py-20">
            <p className="text-slate-400 text-lg mb-2">No destinations found</p>
            <p className="text-slate-400 text-sm">Try adjusting your search or filters</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {filtered.map((dest, i) => (
              <DestinationCard
                key={dest.id}
                destination={dest}
                index={i}
                onClick={() => onOpenDestination(dest)}
                isSaved={savedIds.has(dest.id)}
                onToggleSave={() => toggleSave(dest.id)}
              />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
