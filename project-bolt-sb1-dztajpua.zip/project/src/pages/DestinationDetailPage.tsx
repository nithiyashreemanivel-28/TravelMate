import { useEffect, useState } from 'react';
import { supabase, type Destination, type SavedTrip } from '@/lib/supabase';
import { useAuth } from '@/context/AuthContext';
import {
  ArrowLeft, Star, MapPin, Clock, Calendar, DollarSign, Heart,
  Check, Plane, Utensils, Camera, Shield
} from 'lucide-react';

type Props = {
  destination: Destination;
  onBack: () => void;
};

export default function DestinationDetailPage({ destination, onBack }: Props) {
  const { user } = useAuth();
  const [isSaved, setIsSaved] = useState(false);
  const [activeImage, setActiveImage] = useState(0);
  const [saving, setSaving] = useState(false);
  const [showSavedToast, setShowSavedToast] = useState(false);

  useEffect(() => {
    if (user) checkSaved();
  }, [user, destination.id]);

  const checkSaved = async () => {
    const { data } = await supabase
      .from('saved_trips')
      .select('id')
      .eq('destination_id', destination.id)
      .maybeSingle();
    setIsSaved(!!data);
  };

  const toggleSave = async () => {
    if (!user) return;
    setSaving(true);
    if (isSaved) {
      await supabase.from('saved_trips').delete().eq('destination_id', destination.id);
      setIsSaved(false);
    } else {
      await supabase.from('saved_trips').insert({ destination_id: destination.id, status: 'saved' });
      setIsSaved(true);
      setShowSavedToast(true);
      setTimeout(() => setShowSavedToast(false), 3000);
    }
    setSaving(false);
  };

  const gallery = [destination.image_url, ...destination.gallery];

  const highlights = [
    { icon: Plane, title: 'Flights Included', desc: 'Round-trip airfare from major hubs' },
    { icon: Utensils, title: 'Local Cuisine', desc: 'Authentic dining experiences' },
    { icon: Camera, title: 'Guided Tours', desc: 'Expert local guides included' },
    { icon: Shield, title: 'Travel Insurance', desc: 'Full coverage for peace of mind' },
  ];

  return (
    <div className="min-h-screen pt-16 md:pt-16 pb-20 md:pb-12 bg-slate-50">
      {/* Hero image */}
      <div className="relative h-[400px] md:h-[500px] overflow-hidden">
        <img
          src={gallery[activeImage]}
          alt={destination.name}
          className="absolute inset-0 w-full h-full object-cover transition-all duration-500"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/20 to-black/30" />

        {/* Back button */}
          <button
            onClick={onBack}
            className="absolute top-20 md:top-6 left-4 md:left-6 z-10 flex items-center gap-2 px-4 py-2 rounded-full bg-white/90 backdrop-blur-sm text-slate-700 text-sm font-medium hover:bg-white transition-all"
          >
            <ArrowLeft className="w-4 h-4" />
            Back
          </button>

        {/* Save button */}
        <button
          onClick={toggleSave}
          disabled={saving}
          className="absolute top-20 md:top-6 right-4 md:right-6 z-10 flex items-center gap-2 px-4 py-2 rounded-full bg-white/90 backdrop-blur-sm text-slate-700 text-sm font-medium hover:bg-white transition-all"
        >
          <Heart className={`w-4 h-4 ${isSaved ? 'fill-red-500 text-red-500' : ''}`} />
          {isSaved ? 'Saved' : 'Save Trip'}
        </button>

        {/* Title overlay */}
        <div className="absolute bottom-0 left-0 right-0 p-6 md:p-10 text-white">
          <div className="max-w-7xl mx-auto">
            <div className="flex items-center gap-2 mb-3">
              <span className="px-3 py-1 rounded-full bg-white/20 backdrop-blur-sm text-sm font-medium capitalize">
                {destination.category}
              </span>
              <div className="flex items-center gap-1 px-3 py-1 rounded-full bg-white/20 backdrop-blur-sm">
                <Star className="w-4 h-4 fill-amber-300 text-amber-300" />
                <span className="text-sm font-semibold">{destination.rating}</span>
                <span className="text-sm text-white/70">({destination.reviews_count.toLocaleString()})</span>
              </div>
            </div>
            <h1 className="text-4xl md:text-5xl font-extrabold mb-2 text-shadow-lg" style={{ fontFamily: 'Poppins, sans-serif' }}>
              {destination.name}
            </h1>
            <div className="flex items-center gap-2 text-white/90">
              <MapPin className="w-5 h-5" />
              <span className="text-lg">{destination.country}</span>
            </div>
          </div>
        </div>
      </div>

      {/* Gallery thumbnails */}
      {gallery.length > 1 && (
        <div className="max-w-7xl mx-auto px-6 -mt-8 relative z-10">
          <div className="flex gap-3 overflow-x-auto scrollbar-hide">
            {gallery.map((img, i) => (
              <button
                key={i}
                onClick={() => setActiveImage(i)}
                className={`shrink-0 w-24 h-20 rounded-xl overflow-hidden border-2 transition-all ${
                  activeImage === i ? 'border-cyan-500 scale-105' : 'border-white/80 opacity-80 hover:opacity-100'
                }`}
              >
                <img src={img} alt="" className="w-full h-full object-cover" />
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Content */}
      <div className="max-w-7xl mx-auto px-6 mt-8 grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Left — description & highlights */}
        <div className="lg:col-span-2 space-y-8">
          <div className="bg-white rounded-2xl p-6 md:p-8 card-shadow">
            <h2 className="text-2xl font-bold text-slate-800 mb-4" style={{ fontFamily: 'Poppins, sans-serif' }}>
              About {destination.name}
            </h2>
            <p className="text-slate-600 leading-relaxed text-lg">
              {destination.description}
            </p>
          </div>

          <div className="bg-white rounded-2xl p-6 md:p-8 card-shadow">
            <h2 className="text-2xl font-bold text-slate-800 mb-6" style={{ fontFamily: 'Poppins, sans-serif' }}>
              What's Included
            </h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {highlights.map((item) => (
                <div key={item.title} className="flex items-start gap-3 p-4 rounded-xl bg-slate-50">
                  <div className="w-10 h-10 rounded-lg bg-cyan-50 flex items-center justify-center shrink-0">
                    <item.icon className="w-5 h-5 text-cyan-600" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-slate-800 text-sm">{item.title}</h3>
                    <p className="text-sm text-slate-500">{item.desc}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Reviews summary */}
          <div className="bg-white rounded-2xl p-6 md:p-8 card-shadow">
            <h2 className="text-2xl font-bold text-slate-800 mb-6" style={{ fontFamily: 'Poppins, sans-serif' }}>
              Traveler Reviews
            </h2>
            <div className="flex items-center gap-6 mb-6 pb-6 border-b border-slate-100">
              <div className="text-center">
                <div className="text-5xl font-bold text-slate-800">{destination.rating}</div>
                <div className="flex items-center gap-0.5 justify-center mt-1">
                  {[...Array(5)].map((_, i) => (
                    <Star
                      key={i}
                      className={`w-4 h-4 ${
                        i < Math.floor(destination.rating) ? 'fill-amber-400 text-amber-400' : 'text-slate-200'
                      }`}
                    />
                  ))}
                </div>
                <div className="text-sm text-slate-400 mt-1">{destination.reviews_count.toLocaleString()} reviews</div>
              </div>
              <div className="flex-1 space-y-2">
                {[5, 4, 3, 2, 1].map((star, i) => (
                  <div key={star} className="flex items-center gap-2">
                    <span className="text-xs text-slate-500 w-8">{star} star</span>
                    <div className="flex-1 h-2 rounded-full bg-slate-100 overflow-hidden">
                      <div
                        className="h-full bg-amber-400 rounded-full"
                        style={{ width: `${[85, 10, 3, 1, 1][i]}%` }}
                      />
                    </div>
                    <span className="text-xs text-slate-400 w-10">{[85, 10, 3, 1, 1][i]}%</span>
                  </div>
                ))}
              </div>
            </div>
            <div className="space-y-4">
              {[
                { name: 'Sarah M.', rating: 5, text: 'Absolutely incredible experience! The views were breathtaking and everything was perfectly organized.' },
                { name: 'James K.', rating: 5, text: 'Best trip of my life. The local guides were knowledgeable and the food was amazing.' },
              ].map((review, i) => (
                <div key={i} className="p-4 rounded-xl bg-slate-50">
                  <div className="flex items-center justify-between mb-2">
                    <span className="font-semibold text-slate-800">{review.name}</span>
                    <div className="flex items-center gap-0.5">
                      {[...Array(review.rating)].map((_, j) => (
                        <Star key={j} className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
                      ))}
                    </div>
                  </div>
                  <p className="text-sm text-slate-600">{review.text}</p>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Right — booking card */}
        <div className="lg:col-span-1">
          <div className="bg-white rounded-2xl p-6 card-shadow sticky top-24">
            <div className="mb-6">
              <div className="text-sm text-slate-400 mb-1">Starting from</div>
              <div className="flex items-end gap-2">
                <span className="text-4xl font-bold text-slate-800">${destination.price.toLocaleString()}</span>
                <span className="text-slate-400 mb-1">/ person</span>
              </div>
            </div>

            <div className="space-y-3 mb-6">
              <div className="flex items-center gap-3 p-3 rounded-xl bg-slate-50">
                <Clock className="w-5 h-5 text-cyan-600" />
                <div>
                  <div className="text-xs text-slate-400">Duration</div>
                  <div className="font-semibold text-slate-800">{destination.duration_days} days</div>
                </div>
              </div>
              <div className="flex items-center gap-3 p-3 rounded-xl bg-slate-50">
                <Calendar className="w-5 h-5 text-cyan-600" />
                <div>
                  <div className="text-xs text-slate-400">Best Season</div>
                  <div className="font-semibold text-slate-800">{destination.best_season}</div>
                </div>
              </div>
              <div className="flex items-center gap-3 p-3 rounded-xl bg-slate-50">
                <DollarSign className="w-5 h-5 text-cyan-600" />
                <div>
                  <div className="text-xs text-slate-400">Price Includes</div>
                  <div className="font-semibold text-slate-800">Flights, Hotel, Tours</div>
                </div>
              </div>
            </div>

            <button
              onClick={toggleSave}
              disabled={saving}
              className={`w-full py-3.5 rounded-xl font-semibold transition-all flex items-center justify-center gap-2 ${
                isSaved
                  ? 'bg-red-50 text-red-600 border-2 border-red-200'
                  : 'bg-cyan-600 text-white hover:bg-cyan-700 shadow-lg shadow-cyan-600/25'
              }`}
            >
              {isSaved ? (
                <>
                  <Check className="w-5 h-5" />
                  Trip Saved
                </>
              ) : (
                <>
                  <Heart className="w-5 h-5" />
                  Save This Trip
                </>
              )}
            </button>

            <p className="text-xs text-slate-400 text-center mt-4">
              Free cancellation up to 30 days before departure
            </p>
          </div>
        </div>
      </div>

      {/* Saved toast */}
      {showSavedToast && (
        <div className="fixed bottom-24 md:bottom-8 left-1/2 -translate-x-1/2 z-50 px-6 py-3 rounded-xl bg-slate-800 text-white text-sm font-medium flex items-center gap-2 animate-slide-up shadow-xl">
          <Check className="w-4 h-4 text-green-400" />
          Added to your saved trips!
        </div>
      )}
    </div>
  );
}
