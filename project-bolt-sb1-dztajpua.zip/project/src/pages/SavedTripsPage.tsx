import { useEffect, useState } from 'react';
import { supabase, type Destination, type SavedTrip } from '@/lib/supabase';
import { useAuth } from '@/context/AuthContext';
import { Heart, Calendar, Trash2, MapPin, Clock, DollarSign, Search } from 'lucide-react';

type Props = {
  onOpenDestination: (destination: Destination) => void;
  onNavigate: (page: 'home' | 'explore') => void;
};

export default function SavedTripsPage({ onOpenDestination, onNavigate }: Props) {
  const { user } = useAuth();
  const [trips, setTrips] = useState<(SavedTrip & { destination?: Destination })[]>([]);
  const [loading, setLoading] = useState(true);
  const [filterStatus, setFilterStatus] = useState('all');

  useEffect(() => {
    loadTrips();
  }, [user]);

  const loadTrips = async () => {
    if (!user) return;
    const { data } = await supabase
      .from('saved_trips')
      .select('*, destination:destinations(*)')
      .eq('user_id', user.id)
      .order('created_at', { ascending: false });
    if (data) setTrips(data as (SavedTrip & { destination?: Destination })[]);
    setLoading(false);
  };

  const removeTrip = async (tripId: string) => {
    await supabase.from('saved_trips').delete().eq('id', tripId);
    setTrips((prev) => prev.filter((t) => t.id !== tripId));
  };

  const updateStatus = async (tripId: string, status: string) => {
    await supabase.from('saved_trips').update({ status }).eq('id', tripId);
    setTrips((prev) => prev.map((t) => (t.id === tripId ? { ...t, status } : t)));
  };

  const filtered = filterStatus === 'all' ? trips : trips.filter((t) => t.status === filterStatus);

  const statusColors: Record<string, string> = {
    saved: 'bg-blue-100 text-blue-700',
    planning: 'bg-amber-100 text-amber-700',
    booked: 'bg-green-100 text-green-700',
  };

  if (loading) {
    return (
      <div className="min-h-screen pt-24 pb-20 md:pb-12 bg-slate-50 flex items-center justify-center">
        <div className="animate-pulse text-slate-400">Loading your trips...</div>
      </div>
    );
  }

  return (
    <div className="min-h-screen pt-20 md:pt-24 pb-20 md:pb-12 bg-slate-50">
      <div className="max-w-5xl mx-auto px-6">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center gap-2 text-cyan-600 mb-2">
            <Heart className="w-5 h-5" />
            <span className="text-sm font-semibold uppercase tracking-wide">Your Collection</span>
          </div>
          <h1 className="text-3xl md:text-4xl font-bold text-slate-800 mb-2" style={{ fontFamily: 'Poppins, sans-serif' }}>
            Saved Trips
          </h1>
          <p className="text-slate-500">
            {trips.length === 0 ? 'No saved trips yet' : `${trips.length} ${trips.length === 1 ? 'trip' : 'trips'} saved`}
          </p>
        </div>

        {/* Empty state */}
        {trips.length === 0 ? (
          <div className="bg-white rounded-3xl p-12 text-center card-shadow">
            <div className="w-20 h-20 rounded-full bg-slate-100 flex items-center justify-center mx-auto mb-6">
              <Heart className="w-10 h-10 text-slate-300" />
            </div>
            <h2 className="text-xl font-bold text-slate-800 mb-2">No saved trips yet</h2>
            <p className="text-slate-500 mb-6 max-w-md mx-auto">
              Start exploring destinations and save the ones that catch your eye. They'll appear here for easy planning.
            </p>
            <button
              onClick={() => onNavigate('explore')}
              className="inline-flex items-center gap-2 px-6 py-3 rounded-xl bg-cyan-600 text-white font-semibold hover:bg-cyan-700 transition-all"
            >
              <Search className="w-4 h-4" />
              Explore Destinations
            </button>
          </div>
        ) : (
          <>
            {/* Filter tabs */}
            <div className="flex items-center gap-2 mb-6 overflow-x-auto scrollbar-hide pb-2">
              {['all', 'saved', 'planning', 'booked'].map((status) => (
                <button
                  key={status}
                  onClick={() => setFilterStatus(status)}
                  className={`px-4 py-2 rounded-full text-sm font-medium whitespace-nowrap transition-all capitalize ${
                    filterStatus === status
                      ? 'bg-cyan-600 text-white shadow-lg shadow-cyan-600/20'
                      : 'bg-white text-slate-600 hover:bg-slate-100 border border-slate-200'
                  }`}
                >
                  {status}
                </button>
              ))}
            </div>

            {/* Trip list */}
            <div className="space-y-4">
              {filtered.map((trip, i) => {
              if (!trip.destination) return null;
              const dest = trip.destination;
              return (
                <div
                  key={trip.id}
                  className="bg-white rounded-2xl overflow-hidden card-shadow hover:card-shadow-hover transition-all flex flex-col sm:flex-row animate-slide-up"
                  style={{ animationDelay: `${i * 80}ms`, opacity: 0 }}
                >
                  {/* Image */}
                  <div
                    className="sm:w-56 h-44 sm:h-auto shrink-0 relative overflow-hidden cursor-pointer group"
                    onClick={() => onOpenDestination(dest)}
                  >
                    <img
                      src={dest.image_url}
                      alt={dest.name}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                      loading="lazy"
                    />
                  </div>

                  {/* Content */}
                  <div className="flex-1 p-5 flex flex-col">
                    <div className="flex items-start justify-between mb-2">
                      <div>
                        <div className="flex items-center gap-2 mb-1">
                          <span className={`px-2.5 py-0.5 rounded-full text-xs font-semibold capitalize ${statusColors[trip.status] || statusColors.saved}`}>
                            {trip.status}
                          </span>
                          <span className="text-xs text-slate-400">
                            Saved {new Date(trip.created_at).toLocaleDateString()}
                          </span>
                        </div>
                        <h3
                          className="text-lg font-bold text-slate-800 cursor-pointer hover:text-cyan-600 transition-colors"
                          style={{ fontFamily: 'Poppins, sans-serif' }}
                          onClick={() => onOpenDestination(dest)}
                        >
                          {dest.name}
                        </h3>
                        <div className="flex items-center gap-1 text-slate-500 text-sm mt-0.5">
                          <MapPin className="w-3.5 h-3.5" />
                          {dest.country}
                        </div>
                      </div>
                      <button
                        onClick={() => removeTrip(trip.id)}
                        className="p-2 rounded-lg text-slate-400 hover:bg-red-50 hover:text-red-500 transition-all"
                      >
                        <Trash2 className="w-5 h-5" />
                      </button>
                    </div>

                    <p className="text-sm text-slate-500 leading-relaxed line-clamp-2 mb-3">
                      {dest.description}
                    </p>

                    <div className="flex flex-wrap items-center gap-4 mt-auto pt-3 border-t border-slate-100">
                      <div className="flex items-center gap-1.5 text-slate-500 text-sm">
                        <Clock className="w-4 h-4" />
                        {dest.duration_days} days
                      </div>
                      <div className="flex items-center gap-1.5 text-slate-500 text-sm">
                        <DollarSign className="w-4 h-4" />
                        ${dest.price.toLocaleString()}
                      </div>
                      {trip.planned_date && (
                        <div className="flex items-center gap-1.5 text-slate-500 text-sm">
                          <Calendar className="w-4 h-4" />
                          {new Date(trip.planned_date).toLocaleDateString()}
                        </div>
                      )}
                      <select
                        value={trip.status}
                        onChange={(e) => updateStatus(trip.id, e.target.value)}
                        className="ml-auto text-xs font-medium px-3 py-1.5 rounded-lg border border-slate-200 bg-white text-slate-600 focus:outline-none focus:ring-2 focus:ring-cyan-500"
                      >
                        <option value="saved">Saved</option>
                        <option value="planning">Planning</option>
                        <option value="booked">Booked</option>
                      </select>
                    </div>
                  </div>
                </div>
              );
              })}
            </div>
          </>
        )}
      </div>
    </div>
  );
}
