import { useEffect, useState } from 'react';
import { supabase, type UserProfile, type Destination } from '@/lib/supabase';
import { useAuth } from '@/context/AuthContext';
import { User as UserIcon, Mail, Calendar, Heart, MapPin, Edit2, Check, X, Plane } from 'lucide-react';

type Props = {
  onOpenDestination: (destination: Destination) => void;
  onSignOut: () => void;
};

export default function ProfilePage({ onOpenDestination, onSignOut }: Props) {
  const { user } = useAuth();
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [savedCount, setSavedCount] = useState(0);
  const [recentTrips, setRecentTrips] = useState<(Destination & { trip_id: string })[]>([]);
  const [editing, setEditing] = useState(false);
  const [fullName, setFullName] = useState('');
  const [bio, setBio] = useState('');
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    loadProfile();
    loadStats();
  }, [user]);

  const loadProfile = async () => {
    if (!user) return;
    const { data } = await supabase
      .from('user_profiles')
      .select('*')
      .eq('id', user.id)
      .maybeSingle();
    if (data) {
      setProfile(data as UserProfile);
      setFullName(data.full_name || '');
      setBio(data.bio || '');
    } else {
      const { data: newProfile } = await supabase
        .from('user_profiles')
        .insert({ id: user.id, full_name: user.user_metadata?.full_name || '' })
        .select('*')
        .maybeSingle();
      if (newProfile) {
        setProfile(newProfile as UserProfile);
        setFullName(newProfile.full_name || '');
      }
    }
  };

  const loadStats = async () => {
    if (!user) return;
    const { count } = await supabase
      .from('saved_trips')
      .select('*', { count: 'exact', head: true })
      .eq('user_id', user.id);
    setSavedCount(count || 0);

    const { data: trips } = await supabase
      .from('saved_trips')
      .select('id, destination:destinations(*)')
      .eq('user_id', user.id)
      .order('created_at', { ascending: false })
      .limit(3);
    if (trips) {
      setRecentTrips(
        trips
          .filter((t) => t.destination)
          .map((t) => ({ ...(t.destination as unknown as Destination), trip_id: t.id }))
      );
    }
  };

  const saveProfile = async () => {
    setSaving(true);
    await supabase
      .from('user_profiles')
      .update({ full_name: fullName, bio })
      .eq('id', user?.id);
    setProfile((prev) => (prev ? { ...prev, full_name: fullName, bio } : prev));
    setEditing(false);
    setSaving(false);
  };

  const initials = (profile?.full_name || user?.email || 'U')
    .split(' ')
    .map((s) => s[0])
    .slice(0, 2)
    .join('')
    .toUpperCase();

  return (
    <div className="min-h-screen pt-20 md:pt-24 pb-20 md:pb-12 bg-slate-50">
      <div className="max-w-4xl mx-auto px-6">
        {/* Profile header card */}
        <div className="bg-white rounded-3xl overflow-hidden card-shadow mb-8">
          <div className="h-32 bg-gradient-to-r from-cyan-500 to-cyan-700 relative">
            <div className="absolute inset-0 opacity-20" style={{
              backgroundImage: 'radial-gradient(circle at 20% 50%, white 1px, transparent 1px), radial-gradient(circle at 80% 50%, white 1px, transparent 1px)',
              backgroundSize: '40px 40px',
            }} />
          </div>

          <div className="px-6 md:px-8 pb-8">
            <div className="flex flex-col sm:flex-row items-start sm:items-end gap-4 -mt-16 mb-6">
              {/* Avatar */}
              <div className="w-28 h-28 rounded-2xl bg-cyan-600 text-white flex items-center justify-center text-3xl font-bold border-4 border-white shadow-lg" style={{ fontFamily: 'Poppins, sans-serif' }}>
                {initials}
              </div>

              <div className="flex-1 sm:mb-2">
                {editing ? (
                  <input
                    type="text"
                    value={fullName}
                    onChange={(e) => setFullName(e.target.value)}
                    placeholder="Your name"
                    className="text-2xl font-bold text-slate-800 bg-slate-50 rounded-lg px-3 py-1.5 focus:outline-none focus:ring-2 focus:ring-cyan-500 w-full max-w-xs"
                    style={{ fontFamily: 'Poppins, sans-serif' }}
                  />
                ) : (
                  <h1 className="text-2xl font-bold text-slate-800" style={{ fontFamily: 'Poppins, sans-serif' }}>
                    {profile?.full_name || 'Traveler'}
                  </h1>
                )}
                <div className="flex items-center gap-2 text-slate-500 text-sm mt-1">
                  <Mail className="w-4 h-4" />
                  {user?.email}
                </div>
              </div>

              <button
                onClick={() => (editing ? saveProfile() : setEditing(true))}
                disabled={saving}
                className="flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-all shrink-0"
              >
                {editing ? (
                  <span className="flex items-center gap-1.5 text-green-600 bg-green-50 px-4 py-2 rounded-lg">
                    <Check className="w-4 h-4" /> Save
                  </span>
                ) : (
                  <span className="flex items-center gap-1.5 text-slate-600 bg-slate-100 hover:bg-slate-200 px-4 py-2 rounded-lg">
                    <Edit2 className="w-4 h-4" /> Edit Profile
                  </span>
                )}
                {editing && (
                  <span
                    onClick={() => {
                      setEditing(false);
                      setFullName(profile?.full_name || '');
                      setBio(profile?.bio || '');
                    }}
                    className="flex items-center gap-1.5 text-slate-600 bg-slate-100 hover:bg-slate-200 px-4 py-2 rounded-lg cursor-pointer"
                  >
                    <X className="w-4 h-4" />
                  </span>
                )}
              </button>
            </div>

            {/* Bio */}
            {editing ? (
              <textarea
                value={bio}
                onChange={(e) => setBio(e.target.value)}
                placeholder="Tell us about your travel interests..."
                rows={3}
                className="w-full text-slate-600 bg-slate-50 rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-cyan-500 resize-none"
              />
            ) : (
              profile?.bio && (
                <p className="text-slate-600 leading-relaxed mb-6">{profile.bio}</p>
              )
            )}

            {/* Stats */}
            <div className="grid grid-cols-3 gap-4 pt-6 border-t border-slate-100">
              <div className="text-center">
                <div className="flex items-center justify-center w-10 h-10 rounded-xl bg-red-50 mx-auto mb-2">
                  <Heart className="w-5 h-5 text-red-500" />
                </div>
                <div className="text-2xl font-bold text-slate-800">{savedCount}</div>
                <div className="text-xs text-slate-400">Saved Trips</div>
              </div>
              <div className="text-center">
                <div className="flex items-center justify-center w-10 h-10 rounded-xl bg-cyan-50 mx-auto mb-2">
                  <MapPin className="w-5 h-5 text-cyan-600" />
                </div>
                <div className="text-2xl font-bold text-slate-800">0</div>
                <div className="text-xs text-slate-400">Countries Visited</div>
              </div>
              <div className="text-center">
                <div className="flex items-center justify-center w-10 h-10 rounded-xl bg-amber-50 mx-auto mb-2">
                  <Calendar className="w-5 h-5 text-amber-600" />
                </div>
                <div className="text-2xl font-bold text-slate-800">
                  {profile ? new Date(profile.created_at).getFullYear() : '-'}
                </div>
                <div className="text-xs text-slate-400">Member Since</div>
              </div>
            </div>
          </div>
        </div>

        {/* Recent saved trips */}
        {recentTrips.length > 0 && (
          <div className="mb-8">
            <h2 className="text-xl font-bold text-slate-800 mb-4" style={{ fontFamily: 'Poppins, sans-serif' }}>
              Recently Saved
            </h2>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              {recentTrips.map((dest) => (
                <div
                  key={dest.trip_id}
                  onClick={() => onOpenDestination(dest)}
                  className="group cursor-pointer bg-white rounded-2xl overflow-hidden card-shadow hover:card-shadow-hover transition-all hover:-translate-y-1"
                >
                  <div className="relative h-32 overflow-hidden">
                    <img
                      src={dest.image_url}
                      alt={dest.name}
                      className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                      loading="lazy"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent" />
                    <div className="absolute bottom-2 left-3 text-white">
                      <div className="font-semibold text-sm">{dest.name}</div>
                      <div className="text-xs text-white/70">{dest.country}</div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Sign out */}
        <div className="text-center">
          <button
            onClick={onSignOut}
            className="inline-flex items-center gap-2 px-6 py-3 rounded-xl border border-slate-200 bg-white text-slate-600 font-medium hover:bg-red-50 hover:text-red-600 hover:border-red-200 transition-all"
          >
            <Plane className="w-4 h-4 rotate-90" />
            Sign Out
          </button>
        </div>
      </div>
    </div>
  );
}
