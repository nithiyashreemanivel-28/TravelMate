/*
# TravelMate — Database Schema

1. New Tables
- `destinations` — Pre-populated travel destinations with photos, descriptions, pricing, ratings, and categories.
  - id (uuid, primary key)
  - name (text, not null)
  - country (text, not null)
  - description (text, not null)
  - image_url (text, not null)
  - gallery (text[] — additional image URLs)
  - category (text — beach, city, mountain, cultural, adventure)
  - price (numeric — starting price per person)
  - rating (numeric — average rating 1-5)
  - reviews_count (integer)
  - duration_days (integer — suggested trip length)
  - best_season (text)
  - created_at (timestamptz)

- `user_profiles` — Extended profile info linked to auth.users.
  - id (uuid, primary key — matches auth.users.id)
  - full_name (text)
  - avatar_url (text)
  - bio (text)
  - created_at (timestamptz)

- `saved_trips` — Destinations a user has saved/bookmarked for trip planning.
  - id (uuid, primary key)
  - user_id (uuid, not null, defaults to auth.uid())
  - destination_id (uuid, references destinations)
  - planned_date (date — optional)
  - status (text — saved, planning, booked)
  - notes (text)
  - created_at (timestamptz)

2. Security
- RLS enabled on all tables.
- `destinations`: publicly readable (TO anon, authenticated) — pre-populated catalog.
- `user_profiles`: owner-scoped CRUD (TO authenticated, auth.uid() = id).
- `saved_trips`: owner-scoped CRUD (TO authenticated, auth.uid() = user_id).
- All owner columns default to auth.uid() so inserts succeed without client passing the id.

3. Seed Data
- 8 popular destinations inserted: Maldives, Paris, Tokyo, Santorini, Bali, Swiss Alps, Dubai, New York.
*/

-- Destinations table
CREATE TABLE IF NOT EXISTS destinations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  country text NOT NULL,
  description text NOT NULL,
  image_url text NOT NULL,
  gallery text[] DEFAULT '{}',
  category text NOT NULL DEFAULT 'city',
  price numeric NOT NULL DEFAULT 0,
  rating numeric NOT NULL DEFAULT 4.5,
  reviews_count integer NOT NULL DEFAULT 0,
  duration_days integer NOT NULL DEFAULT 5,
  best_season text NOT NULL DEFAULT 'Year-round',
  created_at timestamptz DEFAULT now()
);

ALTER TABLE destinations ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "public_read_destinations" ON destinations;
CREATE POLICY "public_read_destinations"
  ON destinations FOR SELECT
  TO anon, authenticated USING (true);

-- User profiles table
CREATE TABLE IF NOT EXISTS user_profiles (
  id uuid PRIMARY KEY DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  full_name text DEFAULT '',
  avatar_url text DEFAULT '',
  bio text DEFAULT '',
  created_at timestamptz DEFAULT now()
);

ALTER TABLE user_profiles ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_profile" ON user_profiles;
CREATE POLICY "select_own_profile"
  ON user_profiles FOR SELECT
  TO authenticated USING (auth.uid() = id);

DROP POLICY IF EXISTS "insert_own_profile" ON user_profiles;
CREATE POLICY "insert_own_profile"
  ON user_profiles FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = id);

DROP POLICY IF EXISTS "update_own_profile" ON user_profiles;
CREATE POLICY "update_own_profile"
  ON user_profiles FOR UPDATE
  TO authenticated USING (auth.uid() = id) WITH CHECK (auth.uid() = id);

-- Saved trips table
CREATE TABLE IF NOT EXISTS saved_trips (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  destination_id uuid REFERENCES destinations(id) ON DELETE CASCADE,
  planned_date date,
  status text NOT NULL DEFAULT 'saved',
  notes text DEFAULT '',
  created_at timestamptz DEFAULT now()
);

ALTER TABLE saved_trips ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_trips" ON saved_trips;
CREATE POLICY "select_own_trips"
  ON saved_trips FOR SELECT
  TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "insert_own_trips" ON saved_trips;
CREATE POLICY "insert_own_trips"
  ON saved_trips FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "update_own_trips" ON saved_trips;
CREATE POLICY "update_own_trips"
  ON saved_trips FOR UPDATE
  TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "delete_own_trips" ON saved_trips;
CREATE POLICY "delete_own_trips"
  ON saved_trips FOR DELETE
  TO authenticated USING (auth.uid() = user_id);

-- Indexes
CREATE INDEX IF NOT EXISTS idx_destinations_category ON destinations(category);
CREATE INDEX IF NOT EXISTS idx_saved_trips_user_id ON saved_trips(user_id);

-- Seed destination data
INSERT INTO destinations (name, country, description, image_url, gallery, category, price, rating, reviews_count, duration_days, best_season) VALUES
(
  'Maldives',
  'Maldives',
  'Crystal-clear turquoise waters, overwater bungalows, and pristine coral reefs. The Maldives is the ultimate tropical paradise for relaxation and underwater exploration.',
  'https://images.pexels.com/photos/9149359/pexels-photo-9149359.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
  ARRAY['https://images.pexels.com/photos/29901885/pexels-photo-29901885.jpeg?auto=compress&cs=tinysrgb&h=650&w=940', 'https://images.pexels.com/photos/13833831/pexels-photo-13833831.jpeg?auto=compress&cs=tinysrgb&h=650&w=940', 'https://images.pexels.com/photos/27649542/pexels-photo-27649542.jpeg?auto=compress&cs=tinysrgb&h=650&w=940'],
  'beach', 2400, 4.9, 3245, 6, 'Nov - Apr'
),
(
  'Paris',
  'France',
  'The City of Light. Iconic landmarks like the Eiffel Tower, world-class museums, charming cafes, and romantic streets await in this timeless European capital.',
  'https://images.pexels.com/photos/31482953/pexels-photo-31482953.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
  ARRAY['https://images.pexels.com/photos/17501700/pexels-photo-17501700.jpeg?auto=compress&cs=tinysrgb&h=650&w=940', 'https://images.pexels.com/photos/33733350/pexels-photo-33733350.jpeg?auto=compress&cs=tinysrgb&h=650&w=940'],
  'city', 1800, 4.7, 8901, 4, 'Apr - Jun'
),
(
  'Tokyo',
  'Japan',
  'Where ancient tradition meets cutting-edge technology. Explore neon-lit streets, serene temples, world-class cuisine, and unique pop culture in this dynamic metropolis.',
  'https://images.pexels.com/photos/33901684/pexels-photo-33901684.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
  ARRAY['https://images.pexels.com/photos/30933060/pexels-photo-30933060.jpeg?auto=compress&cs=tinysrgb&h=650&w=940', 'https://images.pexels.com/photos/16789398/pexels-photo-16789398.jpeg?auto=compress&cs=tinysrgb&h=650&w=940'],
  'city', 2200, 4.8, 6723, 7, 'Mar - May'
),
(
  'Santorini',
  'Greece',
  'Stunning whitewashed buildings and blue-domed churches perched on dramatic cliffs above the Aegean Sea. Famous for breathtaking sunsets and Mediterranean cuisine.',
  'https://images.pexels.com/photos/1010657/pexels-photo-1010657.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
  ARRAY['https://images.pexels.com/photos/33851769/pexels-photo-33851769.jpeg?auto=compress&cs=tinysrgb&h=650&w=940', 'https://images.pexels.com/photos/18774878/pexels-photo-18774878.jpeg?auto=compress&cs=tinysrgb&h=650&w=940'],
  'beach', 1600, 4.8, 4567, 5, 'May - Sep'
),
(
  'Bali',
  'Indonesia',
  'Lush rice terraces, ancient temples, and vibrant arts scene. Bali offers a perfect blend of spiritual retreat, adventure activities, and tropical beach relaxation.',
  'https://images.pexels.com/photos/17716409/pexels-photo-17716409.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
  ARRAY['https://images.pexels.com/photos/15994332/pexels-photo-15994332.jpeg?auto=compress&cs=tinysrgb&h=650&w=940', 'https://images.pexels.com/photos/36810327/pexels-photo-36810327.jpeg?auto=compress&cs=tinysrgb&h=650&w=940'],
  'cultural', 1200, 4.7, 5634, 7, 'Apr - Oct'
),
(
  'Swiss Alps',
  'Switzerland',
  'Majestic snow-capped peaks, pristine lakes, and charming alpine villages. Perfect for skiing, hiking, and breathtaking scenic train rides through the mountains.',
  'https://images.pexels.com/photos/37425373/pexels-photo-37425373.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
  ARRAY['https://images.pexels.com/photos/6717138/pexels-photo-6717138.png?auto=compress&cs=tinysrgb&h=650&w=940', 'https://images.pexels.com/photos/16186017/pexels-photo-16186017.jpeg?auto=compress&cs=tinysrgb&h=650&w=940'],
  'mountain', 2800, 4.8, 3211, 5, 'Dec - Mar'
),
(
  'Dubai',
  'United Arab Emirates',
  'Futuristic skyline, luxury shopping, and desert adventures. Dubai blends modern marvels with rich Arabian heritage for an unforgettable urban experience.',
  'https://images.pexels.com/photos/28350363/pexels-photo-28350363.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
  ARRAY['https://images.pexels.com/photos/15693280/pexels-photo-15693280.jpeg?auto=compress&cs=tinysrgb&h=650&w=940', 'https://images.pexels.com/photos/19664340/pexels-photo-19664340.jpeg?auto=compress&cs=tinysrgb&h=650&w=940'],
  'city', 2500, 4.6, 4892, 4, 'Nov - Mar'
),
(
  'New York',
  'United States',
  'The city that never sleeps. Iconic skyline, Broadway shows, world-class museums, diverse neighborhoods, and endless energy make NYC a must-visit destination.',
  'https://images.pexels.com/photos/8569166/pexels-photo-8569166.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
  ARRAY['https://images.pexels.com/photos/12327112/pexels-photo-12327112.jpeg?auto=compress&cs=tinysrgb&h=650&w=940', 'https://images.pexels.com/photos/18388935/pexels-photo-18388935.jpeg?auto=compress&cs=tinysrgb&h=650&w=940'],
  'city', 2000, 4.7, 9876, 5, 'Apr - Jun'
)
ON CONFLICT DO NOTHING;
